﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneManager : MonoBehaviour
{
    private static LoadSceneManager _instance;
    public static LoadSceneManager Instance { get { return _instance; } }

    [SerializeField]
    GameObject m_loadingObj;

    UIProgressBar m_loadingBar;
    AsyncOperation m_loadSceneState;
    public void LoadSceneAsync(string sceneName)
    {
        m_loadSceneState = SceneManager.LoadSceneAsync(sceneName);
        if (m_loadingObj != null)
        {
            m_loadingObj.SetActive(true);
            m_loadingBar.value = 0f;
        }
    }
    private void Awake()
    {
        if(_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }        
    }
    // Start is called before the first frame update
    void Start()
    {
        m_loadingBar = m_loadingObj.GetComponentInChildren<UIProgressBar>();
        m_loadingObj.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (m_loadSceneState != null)
        {
            if (m_loadSceneState.isDone)
            {
                m_loadSceneState = null;
                m_loadingBar.value = 1f;
                m_loadingObj.SetActive(false);
            }
            else
            {
                // Debug.Log((int)(m_sceneLoadState.progress * 100));
                m_loadingBar.value = m_loadSceneState.progress;
            }
        }
    }
}
